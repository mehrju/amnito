﻿using PGTesterApp.Business;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PGTesterApp
{
    public partial class startpayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string myHost = System.Net.Dns.GetHostName();
                string myIP = System.Net.Dns.GetHostEntry(myHost).AddressList[1].ToString();
                lblIPAddress.Text = "My Hostname: " + myHost + "<br />My IP: " + myIP + "<br />" +
                    "Server Variable LOCAL_ADDR: " + Request.ServerVariables["LOCAL_ADDR"];
            }
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            txbxConsole.Text = string.Empty;

            int merchantID, preInvoiceID, merchantConfigID;
            ulong amount;
            if (!int.TryParse(txbxMerchantID.Text.Trim(), out merchantID))
            {
                AddToConsole("کد پذیرنده به درستی وارد نشده است");
                return;
            }

            if (!int.TryParse(txbxPreInvoiceID.Text.Trim(), out preInvoiceID))
            {
                AddToConsole("شماره فاکتور به درستی وارد نشده است");
                return;
            }

            if (!int.TryParse(txbxMerchantConfigID.Text.Trim(), out merchantConfigID))
            {
                AddToConsole("کد پیکربندی پذیرنده به درستی وارد نشده است");
                return;
            }

            if (!ulong.TryParse(txbxAmount.Text.Trim(), out amount))
            {
                AddToConsole("مبلغ ریالی به درستی وارد نشده است");
                return;
            }

            string result, token;
            AsanPardakhtProvider asanPardakhtProvider = new AsanPardakhtProvider(merchantID, merchantConfigID, txbxUsername.Text.Trim(),
                txbxPassword.Text.Trim(), txbxKey.Text.Trim(), txbxIV.Text.Trim());
            bool resultFetched = asanPardakhtProvider.PrepareForPayment(preInvoiceID, amount, out result, out token);
            AddToConsole("Result: " + result);
            AddToConsole("Token: " + token);

            if (resultFetched && result == "0")
            {
                NameValueCollection nvc = new NameValueCollection();
                nvc.Add("RefId", token);
                RedirectWithPost.PageRedirect(this.Page, "https://asan.shaparak.ir", nvc);
                return;
            }
            else
            {
                AddToConsole("مشکلی در اتصال به درگاه پرداخت وجود دارد");
                return;
            }
        }

        private void AddToConsole(string txt)
        {
            txbxConsole.Text += "\n" + txt;
        }
    }
}