﻿using PGTesterApp.Business;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PGTesterApp
{
    public partial class receivepayment : System.Web.UI.Page
    {
        int merchantID = 0, merchantConfigID = 0;
        private string key = "";
        private string iv = "";
        private string username = "";
        private string password = "";

        private void AddToConsole(string txt)
        {
            txbxConsole.Text += "\n" + txt;
        }

        protected void btnVerify_Click(object sender, EventArgs e)
        {
            ulong payGateTranID; ;
            if (ViewState["PayGateTranID"] == null || !ulong.TryParse(ViewState["PayGateTranID"].ToString(), out payGateTranID) || payGateTranID < 1)
            {
                AddToConsole("شماره پیگیری تراکنش وجود ندارد");
                return;
            }

            string verifyRes = string.Empty;
            AsanPardakhtProvider asanPardakhtProvider = new AsanPardakhtProvider(merchantID,
                merchantConfigID, username, password, key, iv);
            bool verified = asanPardakhtProvider.VerifyTrx(payGateTranID, out verifyRes);

            if (verified && verifyRes == "500")
            {
                AddToConsole("وریفای موفق با نتیجه موفق");
                return;
            }
            else
            {
                AddToConsole("VerifyTrx Method Evaluation Result: " + verified.ToString());
                AddToConsole("verifyRes: " + verifyRes);
            }
        }

        protected void btnSettle_Click(object sender, EventArgs e)
        {
            ulong payGateTranID; ;
            if (ViewState["PayGateTranID"] == null || !ulong.TryParse(ViewState["PayGateTranID"].ToString(), out payGateTranID) || payGateTranID < 1)
            {
                AddToConsole("شماره پیگیری تراکنش وجود ندارد");
                return;
            }

            string settleRes = string.Empty;
            AsanPardakhtProvider asanPardakhtProvider = new AsanPardakhtProvider(merchantID,
                merchantConfigID, username, password, key, iv);
            bool settled = asanPardakhtProvider.SettleTrx(payGateTranID, out settleRes);

            if (settled && settleRes == "600")
            {
                AddToConsole("ستل موفق با نتیجه موفق");
                return;
            }
            else
            {
                AddToConsole("SettleTrx Method Evaluation Result: " + settled.ToString());
                AddToConsole("settleRes: " + settleRes);
            }
        }

        protected void btnReversal_Click(object sender, EventArgs e)
        {
            ulong payGateTranID; ;
            if (ViewState["PayGateTranID"] == null || !ulong.TryParse(ViewState["PayGateTranID"].ToString(), out payGateTranID) || payGateTranID < 1)
            {
                AddToConsole("شماره پیگیری تراکنش وجود ندارد");
                return;
            }

            string reversalRes = string.Empty;
            AsanPardakhtProvider asanPardakhtProvider = new AsanPardakhtProvider(merchantID,
                merchantConfigID, username, password, key, iv);
            bool reversed = asanPardakhtProvider.ReverseTrx(payGateTranID, out reversalRes);

            if (reversed && reversalRes == "700")
            {
                AddToConsole("ریورس موفق با نتیجه موفق");
                return;
            }
            else
            {
                AddToConsole("ReverseTrx Method Evaluation Result: " + reversed.ToString());
                AddToConsole("ReverseTrx: " + reversalRes);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                NameValueCollection nvc = Request.Params;
                if (nvc == null)
                {
                    AddToConsole("شما به اشتباه وارد این صفحه شده اید. این صفحه بیانگر نتیجه هیچ تراکنشی نیست");
                    return;
                }

                string returningParamsString = nvc["ReturningParams"];
                string decryptedReturningParamsString = string.Empty;
                AES2 aesProvider = new AES2(key, iv);
                bool decryptionIsSuccessful = aesProvider.Decrypt(returningParamsString, out decryptedReturningParamsString);

                if (!decryptionIsSuccessful)
                {
                    AddToConsole("تراکنشی یافت نشد");
                    AddToConsole("چنانچه وجهی از حساب شما کسر شده باشد، حداکثر ظرف 72 ساعت به حساب شما بازخواهد گشت");
                    return;
                }

                AsanPardakhtPGResultDescriptor trxResultDescriptor = AsanPardakhtPGResultDescriptor.AsanPardakhtTrxResultDescriptorFromString(decryptedReturningParamsString);
                if (trxResultDescriptor == null)
                {
                    AddToConsole("تراکنشی یافت نشد");
                    AddToConsole("چنانچه وجهی از حساب شما کسر شده باشد، حداکثر ظرف 72 ساعت به حساب شما بازخواهد گشت");
                    return;
                }

                int iPreInvoiceID;
                if (!int.TryParse(trxResultDescriptor.PreInvoiceID, out iPreInvoiceID) || iPreInvoiceID < 1)
                {
                    AddToConsole("تراکنشی یافت نشد");
                    AddToConsole("چنانچه وجهی از حساب شما کسر شده باشد، حداکثر ظرف 72 ساعت به حساب شما بازخواهد گشت");
                    return;
                }

                // در این نقطه لازم است شماره پیش فاکتور خود را با نتیجه دریافت شده انطباق دهید
                // آیا چنین شناسه فاکتوری در سیستم شما وجود دارد؟
                // اگر ندارد...                
                //{
                //    AddToConsole("تراکنشی یافت نشد");
                //    AddToConsole("چنانچه وجهی از حساب شما کسر شده باشد، حداکثر ظرف 72 ساعت به حساب شما بازخواهد گشت");
                //    return;
                //}


                // حال لازم است ببینید آیا قبلا نتیجه تراکنش جاری که متناظر با شنایه فاکتوری در سیستم شماست قبلا به شما اعلام شده است
                // اگر قبلا نتیجه این تراکنش را دریافت کرده اید به معنای آن است که باید از درج مجدد آن جلوگیری کنید
                // و احتمالا این اتفاق بدان خاطر رخ داده که کاربر شما صفحه را ریفرش کرده است
                // در چنین شرایطی معمولا بهتر است چنین پیغامی را به کاربر نشان دهید
                //{
                //    AddToConsole("شما قبلا برای این تراکنش وارد صفحه جاری شده اید");
                //    AddToConsole("امکان ورود مجدد به صفحه وجود ندارد");
                //    return;
                //}

                AddToConsole("نتیجه گشودن پاسخ پرداخت از سوی آسان پرداخت به این صفحه به صورت زیر است");
                AddToConsole("iPreInvoiceID: " + iPreInvoiceID);
                AddToConsole("Amount:" + trxResultDescriptor.Amount.ToString());
                AddToConsole("Token: " + trxResultDescriptor.Token);
                AddToConsole("ResCode: " + trxResultDescriptor.ResCode);
                AddToConsole("PayGateTranID: " + trxResultDescriptor.PayGateTranID);
                AddToConsole("MessageText: " + trxResultDescriptor.MessageText);
                AddToConsole("LastFourDigitOfPAN: " + trxResultDescriptor.LastFourDigitOfPAN);
                AddToConsole("RRN: " + trxResultDescriptor.RRN);
                AddToConsole("");
                AddToConsole("");

                // حال لازم است نتیجه تراکنش را در سامانه خود ذخیره کنید. چنانچه مشکلی در ذخیره سازی نتیجه پرداخت وجود داشت لازم است اقدام بیشتر را متوقف کنید
                // و به کاربر اعلام کنید که وجه به حسابش باز خواهد گشت                
                //{
                //    AddToConsole("به دلیل بروز مشکلی امکان ثبت پرداخت شما وجود ندارد");
                //    AddToConsole("چنانچه وجهی از حساب شما کسر شده باشد، حداکثر ظرف 72 ساعت به حساب شما بازخواهد گشت");
                //    return;
                //}

                // آیا کاربر از انجام تراکنش منصرف شده و در صفحه پرداخت دکمه انصراف را زده است؟
                if (trxResultDescriptor.ResCode == "911")
                {
                    AddToConsole("شما از انجام تراکنش منصرف شدید");
                    AddToConsole("در صورت تمایل می توانید دوباره خرید خود را انجام دهید");
                    return;
                }

                // حال لازم است چک نهایی روی شماره پیگیری پرداخت را انجام دهید
                ulong refNumb;
                if (!ulong.TryParse(trxResultDescriptor.PayGateTranID, out refNumb))
                {
                    AddToConsole("به دلیل بروز مشکلی امکان ثبت پرداخت شما وجود ندارد");
                    AddToConsole("چنانچه وجهی از حساب شما کسر شده باشد، حداکثر ظرف 72 ساعت به حساب شما بازخواهد گشت");
                }

                // در حالت عادی شما بعد از دریافت نتیجه قطعی پرداخت موفق، فرآیندهای تسویه یا عودت وجه را بصورت خودکار انجام می دهید
                // اما در این پروژه آموزشی شماره پیگیری تراکنش ذخیره می شود تا با فشار دادن دکمه های متناظر فرآیند های تکمیلی را بصورت دستی انجام دهید
                ViewState["PayGateTranID"] = refNumb;

            }
        }
    }
}